# Copyright Amazon.com, Inc. or its affiliates. All Rights Reserved.
# SPDX-License-Identifier: Apache-2.0

# pylint: disable=no-self-use

import json
import logging
import math
import time
from abc import ABC, abstractmethod
from collections import defaultdict
from typing import Any, Dict, List, Optional, Tuple

from amazon.opentelemetry.distro._utils import should_add_application_signals_dimensions
from opentelemetry.sdk.metrics import Counter
from opentelemetry.sdk.metrics import Histogram as HistogramInstr
from opentelemetry.sdk.metrics import ObservableCounter, ObservableGauge, ObservableUpDownCounter, UpDownCounter
from opentelemetry.sdk.metrics._internal.point import Metric
from opentelemetry.sdk.metrics.export import (
    AggregationTemporality,
    ExponentialHistogram,
    Gauge,
    Histogram,
    MetricExporter,
    MetricExportResult,
    MetricsData,
    NumberDataPoint,
    Sum,
)
from opentelemetry.sdk.metrics.view import ExponentialBucketHistogramAggregation
from opentelemetry.sdk.resources import Resource
from opentelemetry.semconv._incubating.attributes.cloud_attributes import CloudPlatformValues
from opentelemetry.semconv.resource import ResourceAttributes
from opentelemetry.util.types import Attributes

logger = logging.getLogger(__name__)

# Dimension name constants
SERVICE_DIMENSION_NAME: str = "Service"
ENVIRONMENT_DIMENSION_NAME: str = "Environment"

# Resource attribute constant for deployment.environment.name
# deployment.environment is deprecated in favor of deployment.environment.name
# but not yet available in current OTel Python version
# https://github.com/open-telemetry/opentelemetry.io/commit/b04507d7be1e916f6705126c56d66dbe9536503e
DEPLOYMENT_ENVIRONMENT_NAME: str = "deployment.environment.name"

# Constants
UNKNOWN_SERVICE: str = "UnknownService"
UNKNOWN_ENVIRONMENT: str = "generic:default"
EC2_DEFAULT: str = "ec2:default"
ECS_DEFAULT: str = "ecs:default"
EKS_DEFAULT: str = "eks:default"
LAMBDA_DEFAULT: str = "lambda:default"


class MetricRecord:
    """The metric data unified representation of all OTel metrics for OTel to CW EMF conversion."""

    def __init__(self, metric_name: str, metric_unit: str, metric_description: str):
        """
        Initialize metric record.

        Args:
            metric_name: Name of the metric
            metric_unit: Unit of the metric
            metric_description: Description of the metric
        """
        # Instrument metadata
        self.name = metric_name
        self.unit = metric_unit
        self.description = metric_description

        # Will be set by conversion methods
        self.timestamp: Optional[int] = None
        self.attributes: Attributes = {}

        # Different metric type data - only one will be set per record
        self.value: Optional[float] = None
        self.sum_data: Optional[Any] = None
        self.histogram_data: Optional[Any] = None
        self.exp_histogram_data: Optional[Any] = None


class BaseEmfExporter(MetricExporter, ABC):
    """
    Base class for OpenTelemetry metrics exporters that convert to CloudWatch EMF format.

    This class contains all the common logic for converting OTel metrics into CloudWatch EMF logs.
    Subclasses need to implement the _export method to define where the EMF logs are sent.

    https://docs.aws.amazon.com/AmazonCloudWatch/latest/monitoring/CloudWatch_Embedded_Metric_Format_Specification.html

    """

    # CloudWatch EMF supported units
    # Ref: https://docs.aws.amazon.com/AmazonCloudWatch/latest/APIReference/API_MetricDatum.html
    EMF_SUPPORTED_UNITS = {
        "Seconds",
        "Microseconds",
        "Milliseconds",
        "Bytes",
        "Kilobytes",
        "Megabytes",
        "Gigabytes",
        "Terabytes",
        "Bits",
        "Kilobits",
        "Megabits",
        "Gigabits",
        "Terabits",
        "Percent",
        "Count",
        "Bytes/Second",
        "Kilobytes/Second",
        "Megabytes/Second",
        "Gigabytes/Second",
        "Terabytes/Second",
        "Bits/Second",
        "Kilobits/Second",
        "Megabits/Second",
        "Gigabits/Second",
        "Terabits/Second",
        "Count/Second",
        "None",
    }

    # OTel to CloudWatch unit mapping
    # Ref: opentelemetry-collector-contrib/blob/main/exporter/awsemfexporter/grouped_metric.go#L188
    UNIT_MAPPING = {
        "1": "",
        "ns": "",
        "ms": "Milliseconds",
        "s": "Seconds",
        "us": "Microseconds",
        "By": "Bytes",
        "bit": "Bits",
    }

    def __init__(
        self,
        namespace: str = "default",
        preferred_temporality: Optional[Dict[type, AggregationTemporality]] = None,
        preferred_aggregation: Optional[Dict[type, Any]] = None,
    ):
        """
        Initialize the base EMF exporter.

        Args:
            namespace: CloudWatch namespace for metrics
            preferred_temporality: Optional dictionary mapping instrument types to aggregation temporality
            preferred_aggregation: Optional dictionary mapping instrument types to preferred aggregation
        """
        # Set up temporality preference default to DELTA if customers not set
        if preferred_temporality is None:
            preferred_temporality = {
                Counter: AggregationTemporality.DELTA,
                HistogramInstr: AggregationTemporality.DELTA,
                ObservableCounter: AggregationTemporality.DELTA,
                ObservableGauge: AggregationTemporality.DELTA,
                ObservableUpDownCounter: AggregationTemporality.DELTA,
                UpDownCounter: AggregationTemporality.DELTA,
            }

        # Set up aggregation preference default to exponential histogram for histogram metrics
        if preferred_aggregation is None:
            preferred_aggregation = {
                HistogramInstr: ExponentialBucketHistogramAggregation(),
            }

        super().__init__(preferred_temporality, preferred_aggregation)

        self.namespace = namespace

    def _get_metric_name(self, record: MetricRecord) -> Optional[str]:
        """Get the metric name from the metric record or data point."""

        try:
            if record.name:
                return record.name
        except AttributeError:
            pass
        # Return None if no valid metric name found
        return None

    def _get_unit(self, record: MetricRecord) -> Optional[str]:
        """Get CloudWatch unit from MetricRecord unit."""
        unit = record.unit

        if not unit:
            return None

        # First check if unit is already a supported EMF unit
        if unit in self.EMF_SUPPORTED_UNITS:
            return unit

        # Map from OTel unit to CloudWatch unit
        mapped_unit = self.UNIT_MAPPING.get(unit)

        return mapped_unit

    def _get_dimension_names(self, attributes: Attributes) -> List[str]:
        """Extract dimension names from attributes."""
        # Implement dimension selection logic
        # For now, use all attributes as dimensions
        return list(attributes.keys())

    def _add_application_signals_dimensions(
        self, dimension_names: List[str], emf_log: Dict, resource_attributes: Optional[Attributes]
    ) -> None:
        """Add Service and Environment dimensions if not already present."""
        if not should_add_application_signals_dimensions():
            return

        if not self._has_dimension_case_insensitive(dimension_names, SERVICE_DIMENSION_NAME):
            service_name = resource_attributes.get(ResourceAttributes.SERVICE_NAME) if resource_attributes else None
            service_name_str = str(service_name) if service_name else ""
            # https://github.com/open-telemetry/opentelemetry-python/blob/102fec2be1fe9d0a8e299598a21ad6ec3b96dcca/opentelemetry-semantic-conventions/src/opentelemetry/semconv/attributes/service_attributes.py#L20
            if (
                not service_name
                or service_name_str == "unknown_service"
                or service_name_str.startswith("unknown_service:")
            ):
                service_name = UNKNOWN_SERVICE
            dimension_names.append(SERVICE_DIMENSION_NAME)
            emf_log[SERVICE_DIMENSION_NAME] = service_name

        if not self._has_dimension_case_insensitive(dimension_names, ENVIRONMENT_DIMENSION_NAME):
            environment_name = self._get_deployment_environment(resource_attributes)
            dimension_names.append(ENVIRONMENT_DIMENSION_NAME)
            emf_log[ENVIRONMENT_DIMENSION_NAME] = environment_name

    def _has_dimension_case_insensitive(self, dimension_names: List[str], dimension_to_check: str) -> bool:
        """Check if dimension already exists."""
        dimension_lower = dimension_to_check.lower()
        return any(dim.lower() == dimension_lower for dim in dimension_names)

    def _get_deployment_environment(self, resource_attributes: Optional[Attributes]) -> str:
        """Get deployment environment from resource attributes or cloud platform."""
        if not resource_attributes:
            return UNKNOWN_ENVIRONMENT

        environment_name = resource_attributes.get(DEPLOYMENT_ENVIRONMENT_NAME)
        if not environment_name:
            environment_name = resource_attributes.get(ResourceAttributes.DEPLOYMENT_ENVIRONMENT)

        if environment_name:
            return str(environment_name)

        platform = resource_attributes.get(ResourceAttributes.CLOUD_PLATFORM)
        if platform:
            platform_defaults = {
                CloudPlatformValues.AWS_EC2.value: EC2_DEFAULT,
                CloudPlatformValues.AWS_ECS.value: ECS_DEFAULT,
                CloudPlatformValues.AWS_EKS.value: EKS_DEFAULT,
                CloudPlatformValues.AWS_LAMBDA.value: LAMBDA_DEFAULT,
            }
            return platform_defaults.get(str(platform), UNKNOWN_ENVIRONMENT)
        return UNKNOWN_ENVIRONMENT

    def _get_attributes_key(self, attributes: Attributes) -> str:
        """
        Create a hashable key from attributes for grouping metrics.

        Args:
            attributes: The attributes dictionary

        Returns:
            A string representation of sorted attributes key-value pairs
        """
        # Sort the attributes to ensure consistent keys
        sorted_attrs = sorted(attributes.items())
        # Create a string representation of the attributes
        return str(sorted_attrs)

    def _normalize_timestamp(self, timestamp_ns: int) -> int:
        """
        Normalize a nanosecond timestamp to milliseconds for CloudWatch.

        Args:
            timestamp_ns: Timestamp in nanoseconds

        Returns:
            Timestamp in milliseconds
        """
        # Convert from nanoseconds to milliseconds
        return timestamp_ns // 1_000_000

    def _create_metric_record(self, metric_name: str, metric_unit: str, metric_description: str) -> MetricRecord:
        """
        Creates the intermediate metric data structure that standardizes different otel metric representation
        and will be used to generate EMF events. The base record
        establishes the instrument schema (name/unit/description) that will be populated
        with dimensions, timestamps, and values during metric processing.

        Args:
            metric_name: Name of the metric
            metric_unit: Unit of the metric
            metric_description: Description of the metric

        Returns:
            A MetricRecord object
        """
        return MetricRecord(metric_name, metric_unit, metric_description)

    def _convert_gauge_and_sum(self, metric: Metric, data_point: NumberDataPoint) -> MetricRecord:
        """Convert a Gauge or Sum metric datapoint to a metric record.

        Args:
            metric: The metric object
            data_point: The datapoint to convert

        Returns:
            MetricRecord with populated timestamp, attributes, and value
        """
        # Create base record
        record = self._create_metric_record(metric.name, metric.unit, metric.description)

        # Set timestamp
        timestamp_ms = (
            self._normalize_timestamp(data_point.time_unix_nano)
            if data_point.time_unix_nano is not None
            else int(time.time() * 1000)
        )
        record.timestamp = timestamp_ms

        # Set attributes
        record.attributes = data_point.attributes

        # Set the value directly for both Gauge and Sum
        record.value = data_point.value

        return record

    def _convert_histogram(self, metric: Metric, data_point: Any) -> MetricRecord:
        """Convert a Histogram metric datapoint to a metric record.

        https://github.com/open-telemetry/opentelemetry-collector-contrib/blob/main/exporter/awsemfexporter/datapoint.go#L87

        Args:
            metric: The metric object
            data_point: The datapoint to convert

        Returns:
            MetricRecord with populated timestamp, attributes, and histogram_data
        """
        # Create base record
        record = self._create_metric_record(metric.name, metric.unit, metric.description)

        # Set timestamp
        timestamp_ms = (
            self._normalize_timestamp(data_point.time_unix_nano)
            if data_point.time_unix_nano is not None
            else int(time.time() * 1000)
        )
        record.timestamp = timestamp_ms

        # Set attributes
        record.attributes = data_point.attributes

        # For Histogram, set the histogram_data
        record.histogram_data = {
            "Count": data_point.count,
            "Sum": data_point.sum,
            "Min": data_point.min,
            "Max": data_point.max,
        }
        return record

    # pylint: disable=too-many-locals
    def _convert_exp_histogram(self, metric: Metric, data_point: Any) -> MetricRecord:
        """
        Convert an ExponentialHistogram metric datapoint to a metric record.

        This function follows the logic of CalculateDeltaDatapoints in the Go implementation,
        converting exponential buckets to their midpoint values.

        Ref:
            https://github.com/open-telemetry/opentelemetry-collector-contrib/issues/22626

        Args:
            metric: The metric object
            data_point: The datapoint to convert

        Returns:
            MetricRecord with populated timestamp, attributes, and exp_histogram_data
        """

        # Create base record
        record = self._create_metric_record(metric.name, metric.unit, metric.description)

        # Set timestamp
        timestamp_ms = (
            self._normalize_timestamp(data_point.time_unix_nano)
            if data_point.time_unix_nano is not None
            else int(time.time() * 1000)
        )
        record.timestamp = timestamp_ms

        # Set attributes
        record.attributes = data_point.attributes

        # Initialize arrays for values and counts
        array_values = []
        array_counts = []

        # Get scale
        scale = data_point.scale
        # Calculate base using the formula: 2^(2^(-scale))
        base = math.pow(2, math.pow(2, float(-scale)))

        # Process positive buckets
        if data_point.positive and data_point.positive.bucket_counts:
            positive_offset = getattr(data_point.positive, "offset", 0)
            positive_bucket_counts = data_point.positive.bucket_counts

            bucket_begin = 0
            bucket_end = 0

            for bucket_index, count in enumerate(positive_bucket_counts):
                index = bucket_index + positive_offset

                if bucket_begin == 0:
                    bucket_begin = math.pow(base, float(index))
                else:
                    bucket_begin = bucket_end

                bucket_end = math.pow(base, float(index + 1))

                # Calculate midpoint value of the bucket
                metric_val = (bucket_begin + bucket_end) / 2

                # Only include buckets with positive counts
                if count > 0:
                    array_values.append(metric_val)
                    array_counts.append(float(count))

        # Process zero bucket
        zero_count = getattr(data_point, "zero_count", 0)
        if zero_count > 0:
            array_values.append(0)
            array_counts.append(float(zero_count))

        # Process negative buckets
        if data_point.negative and data_point.negative.bucket_counts:
            negative_offset = getattr(data_point.negative, "offset", 0)
            negative_bucket_counts = data_point.negative.bucket_counts

            bucket_begin = 0
            bucket_end = 0

            for bucket_index, count in enumerate(negative_bucket_counts):
                index = bucket_index + negative_offset

                if bucket_end == 0:
                    bucket_end = -math.pow(base, float(index))
                else:
                    bucket_end = bucket_begin

                bucket_begin = -math.pow(base, float(index + 1))

                # Calculate midpoint value of the bucket
                metric_val = (bucket_begin + bucket_end) / 2

                # Only include buckets with positive counts
                if count > 0:
                    array_values.append(metric_val)
                    array_counts.append(float(count))

        # Set the histogram data in the format expected by CloudWatch EMF
        record.exp_histogram_data = {
            "Values": array_values,
            "Counts": array_counts,
            "Count": data_point.count,
            "Sum": data_point.sum,
            "Max": data_point.max,
            "Min": data_point.min,
        }

        return record

    def _group_by_attributes_and_timestamp(self, record: MetricRecord) -> Tuple[str, int]:
        """Group metric record by attributes and timestamp.

        Args:
            record: The metric record

        Returns:
            A tuple key for grouping
        """
        # Create a key for grouping based on attributes
        attrs_key = self._get_attributes_key(record.attributes)
        return (attrs_key, record.timestamp)

    def _create_emf_log(
        self, metric_records: List[MetricRecord], resource: Resource, timestamp: Optional[int] = None
    ) -> Dict:
        """
        Create EMF log dictionary from metric records.

        Since metric_records is already grouped by attributes, this function
        creates a single EMF log for all records.
        """
        # Start with base structure
        emf_log = {"_aws": {"Timestamp": timestamp or int(time.time() * 1000), "CloudWatchMetrics": []}}

        # Set with latest EMF version schema
        # opentelemetry-collector-contrib/blob/main/exporter/awsemfexporter/metric_translator.go#L414
        emf_log["Version"] = "1"

        # Add resource attributes to EMF log but not as dimensions
        # OTel collector EMF Exporter has a resource_to_telemetry_conversion flag that will convert resource attributes
        # as regular metric attributes(potential dimensions). However, for this SDK EMF implementation,
        # we align with the OpenTelemetry concept that all metric attributes are treated as dimensions.
        # And have resource attributes as just additional metadata in EMF, added otel.resource as prefix to distinguish.
        if resource and resource.attributes:
            for key, value in resource.attributes.items():
                emf_log[f"otel.resource.{key}"] = str(value)

        # Initialize collections for dimensions and metrics
        metric_definitions = []
        # Collect attributes from all records (they should be the same for all records in the group)
        # Only collect once from the first record and apply to all records
        all_attributes = (
            metric_records[0].attributes
            if metric_records and len(metric_records) > 0 and metric_records[0].attributes
            else {}
        )

        # Process each metric record
        for record in metric_records:

            metric_name = self._get_metric_name(record)

            # Skip processing if metric name is None or empty
            if not metric_name:
                continue

            # Create metric data dict
            metric_data = {"Name": metric_name}

            unit = self._get_unit(record)
            if unit:
                metric_data["Unit"] = unit

            # Process different types of aggregations
            if record.exp_histogram_data:
                # Base2 Exponential Histogram
                emf_log[metric_name] = record.exp_histogram_data
            elif record.histogram_data:
                # Regular Histogram metrics
                emf_log[metric_name] = record.histogram_data
            elif record.value is not None:
                # Gauge, Sum, and other aggregations
                emf_log[metric_name] = record.value
            else:
                logger.debug("Skipping metric %s as it does not have valid metric value", metric_name)
                continue

            # Add to metric definitions list
            metric_definitions.append(metric_data)

        # Get dimension names from collected attributes
        dimension_names = self._get_dimension_names(all_attributes)

        # Add attribute values to the root of the EMF log
        for name, value in all_attributes.items():
            emf_log[name] = str(value)

        # Add Service and Environment dimensions if Application Signals EMF export is enabled
        resource_attributes = resource.attributes if resource else {}
        self._add_application_signals_dimensions(dimension_names, emf_log, resource_attributes)

        # Add CloudWatch Metrics if we have metrics, include dimensions only if they exist
        if metric_definitions:
            cloudwatch_metric = {"Namespace": self.namespace, "Metrics": metric_definitions}
            if dimension_names:
                cloudwatch_metric["Dimensions"] = [dimension_names]

            emf_log["_aws"]["CloudWatchMetrics"].append(cloudwatch_metric)

        return emf_log

    @abstractmethod
    def _export(self, log_event: Dict[str, Any]):
        """
        Send a log event to the destination (CloudWatch Logs, console, etc.).

        This method must be implemented by subclasses to define where the EMF logs are sent.

        Args:
            log_event: The log event to send
        """

    # pylint: disable=too-many-nested-blocks,unused-argument,too-many-branches
    def export(
        self, metrics_data: MetricsData, timeout_millis: Optional[int] = None, **_kwargs: Any
    ) -> MetricExportResult:
        """
        Export metrics as EMF logs.

        Groups metrics by attributes and timestamp before creating EMF logs.

        Args:
            metrics_data: MetricsData containing resource metrics and scope metrics
            timeout_millis: Optional timeout in milliseconds
            **kwargs: Additional keyword arguments

        Returns:
            MetricExportResult indicating success or failure
        """
        try:
            if not metrics_data.resource_metrics:
                return MetricExportResult.SUCCESS

            # Process all metrics from all resource metrics and scope metrics
            for resource_metrics in metrics_data.resource_metrics:
                for scope_metrics in resource_metrics.scope_metrics:
                    # Dictionary to group metrics by attributes and timestamp
                    grouped_metrics = defaultdict(list)

                    # Process all metrics in this scope
                    for metric in scope_metrics.metrics:
                        # Skip if metric.data is None or no data_points exists
                        try:
                            if not (metric.data and metric.data.data_points):
                                continue
                        except AttributeError:
                            # Metric doesn't have data or data_points attribute
                            continue

                        # Process metrics based on type
                        metric_type = type(metric.data)
                        if metric_type in (Gauge, Sum):
                            for dp in metric.data.data_points:
                                record = self._convert_gauge_and_sum(metric, dp)
                                grouped_metrics[self._group_by_attributes_and_timestamp(record)].append(record)
                        elif metric_type == Histogram:
                            for dp in metric.data.data_points:
                                record = self._convert_histogram(metric, dp)
                                grouped_metrics[self._group_by_attributes_and_timestamp(record)].append(record)
                        elif metric_type == ExponentialHistogram:
                            for dp in metric.data.data_points:
                                record = self._convert_exp_histogram(metric, dp)
                                grouped_metrics[self._group_by_attributes_and_timestamp(record)].append(record)
                        else:
                            logger.debug("Unsupported Metric Type: %s", metric_type)

                    # Now process each group separately to create one EMF log per group
                    for (_, timestamp_ms), metric_records in grouped_metrics.items():
                        if not metric_records:
                            continue

                        # Create and send EMF log for this batch of metrics
                        logger.debug(
                            "Creating EMF log for %d records at timestamp %s",
                            len(metric_records),
                            timestamp_ms,
                        )
                        self._export(
                            {
                                "message": json.dumps(
                                    self._create_emf_log(metric_records, resource_metrics.resource, timestamp_ms)
                                ),
                                "timestamp": timestamp_ms,
                            }
                        )

            return MetricExportResult.SUCCESS
        # pylint: disable=broad-exception-caught
        # capture all types of exceptions to not interrupt the instrumented services
        except Exception as error:
            logger.error("Failed to export metrics: %s", error)
            return MetricExportResult.FAILURE
